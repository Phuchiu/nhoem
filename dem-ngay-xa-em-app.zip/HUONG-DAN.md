# Đếm ngày xa em – cài lên điện thoại

## Cách A: Lấy file APK (Android) – không cần Android Studio
1. Tạo tài khoản GitHub (miễn phí), tạo repository mới, để chế độ Private cũng được.
2. Bấm "Add file" > "Upload files", kéo TOÀN BỘ nội dung đã giải nén của file zip này vào
   (nhớ cả thư mục ẩn .github; nếu web không cho kéo thư mục ẩn, dùng GitHub Desktop hoặc git push).
3. Vào tab "Actions" > "Build APK" > "Run workflow". Đợi khoảng 5–8 phút.
4. Bấm vào lần chạy vừa xong > mục Artifacts > tải "dem-ngay-xa-em-apk" > giải nén được app-debug.apk.
5. Chép file về điện thoại, mở lên, cho phép "Cài ứng dụng từ nguồn không xác định" rồi cài.

## Cách B: Cài như PWA (Android + iPhone)
Đưa thư mục www lên một nơi có HTTPS (GitHub Pages, Netlify, Cloudflare Pages...), mở link bằng
Chrome (Android) hoặc Safari (iPhone) > "Thêm vào màn hình chính".

## Lưu ý
- Dữ liệu lưu trong máy. Gỡ app là mất dữ liệu, hãy dùng "Sao lưu dữ liệu" trước; file zip sẽ mở bảng chia sẻ để bạn lưu vào Drive/Zalo/Files.
- iPhone không cài APK; iPhone dùng Cách B.
